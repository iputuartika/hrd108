<div class="relative text-gray-500 focus-within:text-gray-900 dark:focus-within:text-gray-400">
    <div
        aria-hidden="true"
        class="absolute inset-y-0 flex items-center px-4 pointer-events-none"
    >
        <?php echo e($icon); ?>

    </div>

    <?php echo e($slot); ?>

</div>
<?php /**PATH /media/artika/PortableSSD/MASTER PROGRAM/Project/laravel/resources/views/components/form/input-with-icon-wrapper.blade.php ENDPATH**/ ?>