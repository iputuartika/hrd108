 <?php $__env->slot('header', null, []); ?> 
    <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <h2 class="text-xl font-semibold leading-tight">
            <?php echo e(__('Master Data -> Data Departemen')); ?>

        </h2>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['target' => '_blank','href' => 'https://github.com/kamona-wd/kui-laravel-breeze','variant' => 'black','class' => 'justify-center max-w-xs gap-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '_blank','href' => 'https://github.com/kamona-wd/kui-laravel-breeze','variant' => 'black','class' => 'justify-center max-w-xs gap-2']); ?>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.github','data' => ['class' => 'w-6 h-6','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.github'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <span>Star on Github</span>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
 <?php $__env->endSlot(); ?>

<div>
    <div>
        <!-- Menampilkan pesan -->
        <?php if(session()->has('message')): ?>
        <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3"
            role="alert">
            <div class="flex">
                <div>
                    <p class="text-sm"><?php echo e(session('message')); ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div>
        <!-- Form input departemen -->
        <div>
            <label for="">ID</label>
            <input wire:model="departemen_id" type="text" name="departemen_id" id="departemen_id">
            <label for="">Nama</label>
            <input wire:model="nama" type="text" name="nama" id="nama">
            <label for="">Keterangan</label>
            <input wire:model="keterangan" type="text" name="keterangan" id="keterangan">
            <button wire:click="store()" >Add</button>
        <div>

        <!-- Menampilkan tabel departemens -->
        <table class="border-2">
            <thead>
                <tr>
                    <th>Nama Departemen</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $departemens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departemen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($departemen->departemen_id); ?></td>
                    <td><?php echo e($departemen->nama); ?></td>
                    <td><?php echo e($departemen->keterangan); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH /media/artika/PortableSSD/MASTER PROGRAM/Project/laravel/resources/views/livewire/departemens.blade.php ENDPATH**/ ?>