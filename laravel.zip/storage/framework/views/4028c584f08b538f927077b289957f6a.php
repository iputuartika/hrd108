<div>
    Hello World
</div>
<?php /**PATH D:\IT\PROJECT\Laravel\laravel\resources\views/livewire/hello-world.blade.php ENDPATH**/ ?>