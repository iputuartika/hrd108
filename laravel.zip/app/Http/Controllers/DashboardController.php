<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Karyawan;

class DashboardController extends Controller
{
    //
    public function index()
    {
        $karyawans = Karyawan::all();
        $qty = 1;

        return view('dashboard', ['karyawans' => $karyawans]);
    }
}
