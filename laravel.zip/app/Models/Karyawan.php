<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Karyawan extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'karyawan_id',
        'departemen_id',
        'kecamatan_id',
        'ktp',
        'npwp',
        'nama',
        'tempat_lahir',
        'tanggal_lahir',
        'kontak',
        'email',
        'desa',
        'alamat_lengkap',
        'jenis_kelamin',
        'status',
        'gol_darah',
        'agama',
    ];

    protected $guarded = ['id'];

    public function departemen()
    {
        return $this->belongsTo(Departemen::class);
    }

    public function kecamatan()
    {
        return $this->belongsTo(Kecamatan::class);
    }
}
