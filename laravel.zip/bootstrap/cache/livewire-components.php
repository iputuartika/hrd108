<?php return array (
  'departemens' => 'App\\Http\\Livewire\\Departemens',
  'karyawans' => 'App\\Http\\Livewire\\Karyawans',
  'kecamatans' => 'App\\Http\\Livewire\\Kecamatans',
);